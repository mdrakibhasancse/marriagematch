<img id="profile_pic" align="left" class="fb-image-profile w3-animate-zoom img-thumbnail img-fluid" src="{{ route('imagecache', ['template' => 'pplg', 'filename' => $user->fi()]) }}" alt="Profile image example"/>
<br>
