<div class="modal fade" id="proposalSentModal">
    <div class="modal-dialog">
        <div class="modal-content contentContainer">

            <div class="modal-header">
            <h4 class="modal-title">Proposal</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body" style="min-height: 200px;">
            <div class="text-center w3-xlarge">
                <div class="spinner-grow spinner-grow-lg w3-deep-orange">
                   
                </div> 
                <span>Loading </span>
            </div>
              
        </div>       
        
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

