<div class="card">
    <div class="card-header">
        <h4 class="card-title" style="">
            <i class="fa fa-credit-card w3-text-deep-orange"></i>&nbsp;
            পেমেন্ট করার জন্য &nbsp; <span class="w3-text-deep-orange"><b> Membership Package </b></span>&nbsp; বাটনে ক্লিক করুন । একটি প্যাকেজ সিলেক্ট করে &nbsp;<span class="w3-text-deep-orange"><b>Continue</b></span>&nbsp; করুন ।
        </h4>
    </div>
</div>