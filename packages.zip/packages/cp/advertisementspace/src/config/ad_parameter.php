<?php

return [

    'position' => [
        'top', 'right',  'bottom', 'left', 'middle',
    ],

];