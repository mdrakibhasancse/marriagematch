<?php

namespace Cp\AdvertisementSpace\Controllers;

use Auth;
use App\Http\Controllers\Controller;

class AdvertisementSpaceController extends Controller
{
    // public function myMenupage($value = '')
    // {
    //     return view('menupage::menu.welcome');
    // }
}
