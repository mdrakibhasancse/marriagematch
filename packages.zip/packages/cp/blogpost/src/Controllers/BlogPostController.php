<?php

namespace Cp\BlogPost\Controllers;

use Auth;
use Event;
use Validator;
use Carbon\Carbon;
use App\Models\User;
use Cp\Menupage\Models\Menu;
use App\Http\Controllers\Controller;

class BlogPostController extends Controller
{
    // public function myMenupage($value = '')
    // {
    //     return view('menupage::menu.welcome');
    // }
}
