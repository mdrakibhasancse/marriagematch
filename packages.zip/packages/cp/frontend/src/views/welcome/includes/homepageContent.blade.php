<div style="" class="m-0 p-0">@foreach ($homePage->pageItems as $item){!! $item->description !!}@endforeach</div>




