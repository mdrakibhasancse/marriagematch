<a id="btn-profilepic" class="btn-profilepic" title="Change Feature Image">
    <img align="left" class="fb-image-profile w3-animate-zoom img-thumbnail w-100 mb-3" style="max-width: 250px;" src="{{ route('imagecache', ['template' => 'pplg', 'filename' => $user->fi()]) }}" alt="Profile image"/>
</a>