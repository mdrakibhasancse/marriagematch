<?php

namespace Cp\Gallery\Controllers;


use App\Http\Controllers\Controller;


class GalleryController extends Controller
{
}
