<?php

return [

    'story_type' => [
        'story', 'testimonial',
    ],

];
