<?php

namespace Cp\JobPost\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JobPostCv extends Model
{
    use HasFactory;
}
