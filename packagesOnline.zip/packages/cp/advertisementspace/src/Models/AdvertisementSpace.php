<?php



namespace Cp\AdvertisementSpace\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AdvertisementSpace extends Model
{
    use HasFactory;
}
